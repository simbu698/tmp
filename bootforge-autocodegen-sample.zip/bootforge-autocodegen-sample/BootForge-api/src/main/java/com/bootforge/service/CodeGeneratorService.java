package com.bootforge.service;

import com.bootforge.model.ProjectInput;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class CodeGeneratorService {

    private final Configuration cfg;

    public CodeGeneratorService() throws IOException {
        cfg = new Configuration(Configuration.VERSION_2_3_30);
        cfg.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
    }

    public String generateProject(ProjectInput input) throws IOException {
        String outputDir = "generated-" + UUID.randomUUID();
        Files.createDirectories(Paths.get(outputDir + "/src/main/java/com/example"));
        Map<String, Object> dataModel = new HashMap<>();
        dataModel.put("libraries", input.getLibraries());
        dataModel.put("database", input.getDatabase());

        generateFile("pom.ftl", outputDir + "/pom.xml", dataModel);
        generateFile("application.ftl", outputDir + "/src/main/resources/application.properties", dataModel);

        String zipPath = outputDir + ".zip";
        zipFolder(Paths.get(outputDir), Paths.get(zipPath));
        return zipPath;
    }

    private void generateFile(String templateName, String outputPath, Map<String, Object> dataModel) throws IOException {
        try (Writer fileWriter = new FileWriter(outputPath)) {
            Template template = cfg.getTemplate(templateName);
            template.process(dataModel, fileWriter);
        } catch (TemplateException e) {
            e.printStackTrace();
        }
    }

    private void zipFolder(Path sourceDir, Path zipFile) throws IOException {
        try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(zipFile))) {
            Files.walk(sourceDir).filter(path -> !Files.isDirectory(path)).forEach(path -> {
                ZipEntry zipEntry = new ZipEntry(sourceDir.relativize(path).toString());
                try {
                    zs.putNextEntry(zipEntry);
                    Files.copy(path, zs);
                    zs.closeEntry();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
    }
}