package com.bootforge.controller;

import com.bootforge.model.ProjectInput;
import com.bootforge.service.CodeGeneratorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;

@RestController
@RequestMapping("/generate")
public class GenerateController {

    private final CodeGeneratorService generatorService = new CodeGeneratorService();

    @PostMapping
    public ResponseEntity<String> generateProject(@RequestBody ProjectInput input) throws IOException {
        String zipPath = generatorService.generateProject(input);
        return ResponseEntity.ok(zipPath);
    }
}