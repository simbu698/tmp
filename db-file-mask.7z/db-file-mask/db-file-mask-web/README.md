# DB File Masking Tool - Frontend

A React application to upload exported database files (.csv, .xls, .xml, .json, .dmp, .sstable) for data masking to lower environments.

## 💻 Tech Stack
- React
- Axios
- Lucide Icons
- CSS Modules

## 📁 File Types Supported
- `.csv`
- `.xls`, `.xlsx`
- `.json`
- `.xml`
- `.dmp`
- `.sstable`

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install