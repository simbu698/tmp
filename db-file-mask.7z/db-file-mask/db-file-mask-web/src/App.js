import React from "react";
import FileUploadPage from "./components/FileUploadPage/FileUploadPage";

const App = () => {
  return (
    <div>
      <FileUploadPage />
    </div>
  );
};

export default App;