import React from "react";
import { useNavigate } from "react-router-dom";

const ConfirmationPage = ({ columns = [], data = [], maskColumns = [] }) => {
  const navigate = useNavigate();

  const handleConfirm = () => {
    navigate("/upload"); // Redirect to upload form
  };

  return (
    <div style={{ maxWidth: 800, margin: "40px auto", padding: 24, background: "#fff", borderRadius: 12, boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}>
      <h2>Confirm Your Selection</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 24 }}>
        <thead>
          <tr>
            {columns.map((col, idx) => (
              <th key={idx} style={{ border: "1px solid #ddd", padding: 8, background: "#f5f5f5" }}>{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rIdx) => (
            <tr key={rIdx}>
              {row.map((cell, cIdx) => (
                <td
                  key={cIdx}
                  style={{
                    border: "1px solid #ddd",
                    padding: 8,
                    background: maskColumns.includes(cIdx) ? "#ffe082" : "#fff"
                  }}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <button
        onClick={handleConfirm}
        style={{ padding: "10px 32px", background: "#1976d2", color: "#fff", border: "none", borderRadius: 6, fontWeight: 600, cursor: "pointer" }}
      >
        Confirm
      </button>
    </div>
  );
};

export default ConfirmationPage;