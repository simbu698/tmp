import React, { useState, useMemo } from "react";
import './DataGrid.css';

const DataGrid = ({ columns, data, maskColumns, setMaskColumns }) => {
  const [sortColumn, setSortColumn] = useState(null);
  const [sortDirection, setSortDirection] = useState("asc");

  const handleSort = (colIdx) => {
    if (sortColumn === colIdx) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(colIdx);
      setSortDirection("asc");
    }
  };

  const handleMaskChange = (colIdx) => {
    setMaskColumns((prev) =>
      prev.includes(colIdx)
        ? prev.filter((idx) => idx !== colIdx)
        : [...prev, colIdx]
    );
  };

  const sortedData = useMemo(() => {
    if (sortColumn === null) return data;
    return [...data].sort((a, b) => {
      if (a[sortColumn] < b[sortColumn]) return sortDirection === "asc" ? -1 : 1;
      if (a[sortColumn] > b[sortColumn]) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [data, sortColumn, sortDirection]);

  return (
    <>
      <table className="attractive-table">
        <thead>
          <tr>
            {columns.map((col, idx) => (
              <th key={idx} className="sortable">
                <input
                  type="checkbox"
                  checked={maskColumns.includes(idx)}
                  onChange={() => handleMaskChange(idx)}
                  style={{ marginRight: 6 }}
                />
                <span onClick={() => handleSort(idx)} style={{ cursor: "pointer" }}>
                  {col}
                  {sortColumn === idx && (
                    <span className="sort-arrow">
                      {sortDirection === "asc" ? "▲" : "▼"}
                    </span>
                  )}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, idx) => (
            <tr key={idx}>
              {row.map((cell, cidx) => (
                <td key={cidx}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default DataGrid;