import React, { useRef, useState } from "react";
import axios from "axios";
import { UploadCloud } from "lucide-react";

const allowedTypes = ["csv", "xls", "xlsx", "json", "xml", "dmp", "sstable"];

const FileUpload = ({
  setTableColumns,
  setTableData,
  selectedFile,
  setSelectedFile,
  uploadStatus,
  setUploadStatus,
}) => {
  const inputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);

  const validateFile = (file) => {
    const extension = file.name.split(".").pop().toLowerCase();
    return allowedTypes.includes(extension);
  };

  const parseFile = (file) => {
    if (file.name.endsWith(".csv")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const rows = text.split("\n").map(row => row.split(","));
        setTableColumns(rows[0]);
        setTableData(rows.slice(1).filter(row => row.length === rows[0].length));
      };
      reader.readAsText(file);
    } else if (file.name.endsWith(".json")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target.result);
          if (Array.isArray(json) && json.length > 0) {
            setTableColumns(Object.keys(json[0]));
            setTableData(json.map(obj => Object.values(obj)));
          } else {
            setTableColumns([]);
            setTableData([]);
          }
        } catch {
          setTableColumns([]);
          setTableData([]);
        }
      };
      reader.readAsText(file);
    } else {
      setTableColumns([]);
      setTableData([]);
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file && validateFile(file)) {
      setSelectedFile(file);
      setUploadStatus("");
      parseFile(file);
    } else if (file) {
      setUploadStatus("Unsupported file format");
      setSelectedFile(null);
      setTableColumns([]);
      setTableData([]);
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (validateFile(file)) {
        setSelectedFile(file);
        setUploadStatus("");
        parseFile(file);
      } else {
        setUploadStatus("Unsupported file format");
        setSelectedFile(null);
        setTableColumns([]);
        setTableData([]);
      }
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setUploadStatus("Please select a valid file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", selectedFile);
    try {
      const response = await axios.post("/api/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setUploadStatus(`File uploaded successfully: ${response.data.message}`);
    } catch {
      setUploadStatus("File upload failed. Please try again.");
    }
  };

  return (
    <div
      className={`upload-dropzone${dragActive ? " active" : ""}`}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
      onClick={() => inputRef.current.click()}
    >
      <input
        type="file"
        ref={inputRef}
        onChange={handleFileChange}
        accept=".csv,.xls,.xlsx,.json,.xml,.dmp,.sstable"
        className="upload-input"
        style={{ display: "none" }}
      />
      <UploadCloud size={32} />
      <p>Drag & drop file here, or click to select</p>
      {selectedFile && <p>Selected: {selectedFile.name}</p>}
      <div className="upload-button-row">
        <button onClick={handleUpload} className="upload-button">
          <UploadCloud size={18} /> Upload
        </button>
      </div>
    </div>
  );
};

export default FileUpload;