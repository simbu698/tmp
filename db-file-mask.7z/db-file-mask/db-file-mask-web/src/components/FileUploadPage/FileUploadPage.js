import React, { useState } from "react";
import FileUpload from "./FileUpload";
import DataGrid from "./DataGrid";
import ConfirmationPage from "./ConfirmationPage";
import "./FileUploadPage.css";

const FileUploadPage = () => {
  const [tableColumns, setTableColumns] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState("");
  const [maskColumns, setMaskColumns] = useState([]);
  const [step, setStep] = useState("table"); // "table" or "confirm"

  const handleProceed = () => setStep("confirm");
  const handleBack = () => setStep("table");

  return (
    <div className="upload-page-container">
      <div className="upload-section">
        <FileUpload
          setTableColumns={setTableColumns}
          setTableData={setTableData}
          selectedFile={selectedFile}
          setSelectedFile={setSelectedFile}
          uploadStatus={uploadStatus}
          setUploadStatus={setUploadStatus}
        />
      </div>
      <div className="table-section">
        {step === "table" && tableColumns.length > 0 && tableData.length > 0 && (
          <>
            <DataGrid
              columns={tableColumns}
              data={tableData}
              maskColumns={maskColumns}
              setMaskColumns={setMaskColumns}
            />
            <button
              style={{
                marginTop: 24,
                padding: "10px 32px",
                background: "#1976d2",
                color: "#fff",
                border: "none",
                borderRadius: 6,
                fontWeight: 600,
                cursor: "pointer"
              }}
              onClick={handleProceed}
            >
              Proceed
            </button>
          </>
        )}
        {step === "confirm" && Array.isArray(tableColumns) && tableColumns.length > 0 && (
          <ConfirmationPage
            columns={tableColumns}
            data={tableData}
            maskColumns={maskColumns}
          />
        )}
      </div>
    </div>
  );
};

export default FileUploadPage;