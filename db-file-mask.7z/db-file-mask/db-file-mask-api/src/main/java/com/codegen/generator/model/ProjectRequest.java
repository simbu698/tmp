package com.codegen.generator.model;

import lombok.Data;

@Data
public class ProjectRequest {
    private String groupId;
    private String artifactId;
    private String entity;
    private String basePackage;
}
