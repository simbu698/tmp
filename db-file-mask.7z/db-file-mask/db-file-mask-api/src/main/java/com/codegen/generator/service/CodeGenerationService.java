package com.codegen.generator.service;

import com.codegen.generator.model.ProjectRequest;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.*;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class CodeGenerationService {

    public Path generateProject(ProjectRequest request) throws IOException {
        Map<String, String> values = Map.of(
                "groupId", request.getGroupId(),
                "artifactId", request.getArtifactId(),
                "Entity", capitalize(request.getEntity()),
                "entityName", request.getEntity().toLowerCase(),
                "package", request.getBasePackage(),
                "packagePath", request.getBasePackage().replace(".", "/")
        );

        Path tempDir = Files.createTempDirectory("project_");
        generateFromTemplate("Controller.java.template", tempDir.resolve("src/main/java/" + values.get("packagePath") + "/controller/" + values.get("Entity") + "Controller.java"), values);
        // Add more templates here

        Path zipPath = Files.createTempFile("project_", ".zip");
        try (ZipOutputStream zipOut = new ZipOutputStream(Files.newOutputStream(zipPath))) {
            Files.walk(tempDir).filter(Files::isRegularFile).forEach(path -> {
                ZipEntry entry = new ZipEntry(tempDir.relativize(path).toString());
                try {
                    zipOut.putNextEntry(entry);
                    Files.copy(path, zipOut);
                    zipOut.closeEntry();
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }

        return zipPath;
    }

    private void generateFromTemplate(String templateName, Path outputPath, Map<String, String> values) throws IOException {
        String template = Files.readString(Paths.get("src/main/resources/templates/" + templateName));
        String content = TemplateProcessor.process(template, values);
        Files.createDirectories(outputPath.getParent());
        Files.writeString(outputPath, content);
    }

    private String capitalize(String s) {
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
