package com.codegen.generator;

import com.codegen.generator.model.ProjectRequest;
import com.codegen.generator.service.CodeGenerationService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Path;

@RestController
@RequestMapping("/generate")
public class CodeGenerationController {

    private final CodeGenerationService service;

    public CodeGenerationController(CodeGenerationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Resource> generate(@RequestBody ProjectRequest request) throws IOException {
        Path zipPath = service.generateProject(request);
        Resource resource = new FileSystemResource(zipPath.toFile());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=project.zip")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }
}
