import SummaryPieChart from "../components/SummaryPieChart";
import SplitterMigrationChart from "../components/SplitterMigrationChart";
import WPIMigrationChart from "../components/WPIMigrationChart";
import Total1BarChart from "../components/TotalBarCharts/Total1BarChart";
import Total2BarChart from "../components/TotalBarCharts/Total2BarChart";
import Total3BarChart from "../components/TotalBarCharts/Total3BarChart";
import DataGrid from "../components/DataGrid";
import TrendIndicator from '../components/TrendIndicator';

const Dashboard = () => {
  return (
    <div className="dashboard-container">
  <div className="chart-container">
    <div className="chart">
      <SummaryPieChart />
    </div>
    <div className="chart">
      <SplitterMigrationChart />
    </div>
    <div className="chart">
      <WPIMigrationChart />
    </div>
    <div className="chart">
      <Total1BarChart />
    </div>
    <div className="chart">
      <Total2BarChart />
    </div>
    <div className="chart">
      <Total3BarChart />
    </div>
    <div className="chart">
      <TrendIndicator />
    </div>
  </div>
  <div className="data-grid-container">
    <DataGrid />
  </div>
</div>
  );
};

export default Dashboard;
