import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const Total3BarChart = () => {
  const options = {
    chart: { type: "bar" },
    title: { text: "Total 3 Bar Chart" },
    xAxis: { categories: ["Category C"] },
    series: [
      { name: "Value", data: [100] },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default Total3BarChart;