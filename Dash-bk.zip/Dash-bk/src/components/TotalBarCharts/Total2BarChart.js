import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const Total2BarChart = () => {
  const options = {
    chart: { type: "bar" },
    title: { text: "Total 2 Bar Chart" },
    xAxis: { categories: ["Category B"] },
    series: [
      { name: "Value", data: [75] },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default Total2BarChart;