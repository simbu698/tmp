import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const Total1BarChart = () => {
  const options = {
    chart: { type: "bar" },
    title: { text: "Total 1 Bar Chart" },
    xAxis: { categories: ["Category A"] },
    series: [
      { name: "Value", data: [50] },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default Total1BarChart;