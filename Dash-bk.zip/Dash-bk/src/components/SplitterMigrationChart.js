import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const SplitterMigrationChart = () => {
  const options = {
    chart: { type: "column" },
    title: { text: "Splitter Migration by Week" },
    xAxis: { categories: ["Week 1", "Week 2", "Week 3"] },
    series: [
      { name: "Splitter A", data: [15, 25, 20] },
      { name: "Splitter B", data: [10, 20, 30] },
      { name: "Splitter C", data: [5, 15, 10] },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};

export default SplitterMigrationChart;