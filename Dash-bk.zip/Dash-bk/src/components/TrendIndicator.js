import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const TrendIndicator = () => {
  const options = {
    chart: { type: "bar" },
    title: { text: "Trend Indicator" },
    xAxis: { categories: ["Indicator"] },
    series: [
      { name: "Score", data: [8], color: "#4CAF50" },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default TrendIndicator;