import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const SummaryPieChart = () => {
  const options = {
    chart: { type: "pie" },
    title: { text: "Summary of Last 3 Weeks" },
    series: [
      {
        name: "Summary",
        data: [
          { name: "Category A", y: 30 },
          { name: "Category B", y: 20 },
          { name: "Category C", y: 25 },
          { name: "Category D", y: 25 },
        ],
      },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default SummaryPieChart;