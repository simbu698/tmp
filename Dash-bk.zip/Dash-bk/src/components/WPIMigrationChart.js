import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";

const WPIMigrationChart = () => {
  const options = {
    chart: { type: "column" },
    title: { text: "WPI Migration by Week" },
    xAxis: { categories: ["Week 1", "Week 2", "Week 3"] },
    series: [
      { name: "Category A", data: [10, 20, 15] },
      { name: "Category B", data: [5, 15, 25] },
      { name: "Category C", data: [8, 12, 18] },
    ],
  };

  return <HighchartsReact highcharts={Highcharts} options={options} />;
};
export default WPIMigrationChart;