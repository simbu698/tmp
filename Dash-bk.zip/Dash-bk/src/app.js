import Dashboard from "./pages/Dashboard";

const App = () => {
  return <Dashboard />;
};

export default App;
